# cpu_pipeline
The final project for COEN 122 - "Computer Architecture" at Santa Clara University.

This module contains the verilog files describing our pipelined CPU, designed as a part of the final project for COEN 122. We used Vivado
for testing this code, and thus the repo is simply a copy of a Vivado project directory.
(*HOORAY FOR ARCANELY STRUCTURED WORKING DIRECTORIES*)
